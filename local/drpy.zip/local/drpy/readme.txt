本地包版本:20241012-1
作者:道长
QQ群:824179147
PC:zyplayer 与 Mobile:影视 通用

zyplayer导入教程:
1.drpy_dzlive整个文件夹丢到zy服务目录的根目录，注意不是安装目录(写源工具-运行-服务)
2.zy设置数据导入hipy源输入下面的地址:
http://127.0.0.1:9978/api/v1/file/drpy_dzlive/

手机导入教程:
1.新增订阅添加以下内容: file://Download/local/drpy/index.json

其他说明:
index.js仅限zyplayer配置使用
index.json可以给手机壳子easybox使用本地包


更新说明:
20241012
更新了index.js支持了appv2模板传参,新增appv2.txt示例